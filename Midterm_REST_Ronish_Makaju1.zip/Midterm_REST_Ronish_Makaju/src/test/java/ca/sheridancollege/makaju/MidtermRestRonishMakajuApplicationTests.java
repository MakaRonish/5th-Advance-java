package ca.sheridancollege.makaju;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MidtermRestRonishMakajuApplicationTests {

	@Test
	void contextLoads() {
	}

}
