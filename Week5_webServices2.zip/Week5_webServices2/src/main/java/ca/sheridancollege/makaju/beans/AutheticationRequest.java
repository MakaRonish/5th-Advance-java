package ca.sheridancollege.makaju.beans;

public class AutheticationRequest {
	private String email;
	private String password;

}
