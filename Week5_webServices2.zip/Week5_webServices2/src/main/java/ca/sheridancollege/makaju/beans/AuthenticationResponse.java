package ca.sheridancollege.makaju.beans;

public class AuthenticationResponse {
	private String token;

}
