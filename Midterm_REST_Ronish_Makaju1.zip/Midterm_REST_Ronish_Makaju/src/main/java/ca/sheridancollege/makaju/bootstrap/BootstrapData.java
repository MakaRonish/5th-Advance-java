package ca.sheridancollege.makaju.bootstrap;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import ca.sheridancollege.makaju.beans.Shirt;
import ca.sheridancollege.makaju.beans.Therapist;
import ca.sheridancollege.makaju.repositories.ShirtRepository;
import ca.sheridancollege.makaju.repositories.TherapistRepository;
import lombok.AllArgsConstructor;

@Component
@AllArgsConstructor
public class BootstrapData implements CommandLineRunner {
	
	private ShirtRepository shirtRepo;
	private TherapistRepository therapistRepo;

	@Override
	public void run(String... args) throws Exception {
		Therapist t1  =Therapist.builder().name("Ronish").build();
		Therapist t2 = Therapist.builder().name("Priya").build();
		Therapist t3 = Therapist.builder().name("Rey").build();
		
		Shirt s1 = Shirt.builder().name("full shleve").price(99).quantity(4).employeeName("Ronish").build();
		Shirt s2 = Shirt.builder().name("half sleeve").price(79).quantity(8).employeeName("Priya").build();

		Shirt s3 = Shirt.builder().name("polo shirt").price(89).quantity(6).employeeName("Rey").build();

		Shirt s4 = Shirt.builder().name("denim shirt").price(120).quantity(40).employeeName("Ronish").build();

		Shirt s5 = Shirt.builder().name("casual shirt").price(69).quantity(90).employeeName("Ronish").build();

		Shirt s6 = Shirt.builder().name("formal shirt").price(110).quantity(50).employeeName("Priya").build();

		Shirt s7 = Shirt.builder().name("linen shirt").price(130).quantity(3).employeeName("Rey").build();

		Shirt s8 = Shirt.builder().name("checked shirt").price(95).quantity(70).employeeName("Priya").build();

		Shirt s9 = Shirt.builder().name("striped shirt").price(85).quantity(5).employeeName("Priya").build();

		Shirt s10 = Shirt.builder().name("flannel shirt").price(105).quantity(4).employeeName("Ronish").build();
		
		shirtRepo.saveAll(List.of(s1,s2,s3,s4,s5,s6,s7,s8,s9,s10));
		therapistRepo.saveAll(List.of(t1,t2,t3));
		

	}

}
