package ca.sheridancollege.makaju.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import ca.sheridancollege.makaju.beans.repositories.UserRepository;
import ca.sheridancollege.makaju.bootstraps.BootstrapData;
import lombok.AllArgsConstructor;

@Configuration
@AllArgsConstructor
public class ApplicationConfig {

    private final BootstrapData bootstrapData;
	
	private UserRepository userRepository;

    ApplicationConfig(BootstrapData bootstrapData) {
        this.bootstrapData = bootstrapData;
    }
    
    @Bean
	public UserDetailsService userDetailService() {
		return username -> userRepository.findByEmail(username).
				orElseThrow(()-> new UsernameNotFoundException("User Not FOund"));
	}
    
    @Bean
    public  AuthenticationProvider authenticationProvider(UserDetailsService userDetailsService) {
    	DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider(userDetailsService);
    	authProvider.setPasswordEncoder(passwordEncoder());
    	return authProvider;
    }
    
    @Bean 
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception{
    	return config.getAuthenticationManager();
    }
    
    @Bean
    public PasswordEncoder passwordEncoder() {
    	return new BCryptPasswordEncoder();
    }
}

